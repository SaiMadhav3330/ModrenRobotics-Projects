# Course 4 Week 1 (A\* Search) Project

## Contents
- `code` is where all code is located. `project.py` implements a class for
storing a graph and pathfinding using A\* search.
- `results` is where the input `nodes.csv` and `edges.csv` files,
`obstacles.csv`, and output `path.csv` file is stored.
- `ss.png` is a screenshot of the simulation environment showing the path.
- `samplePath.csv` is the sample path downloaded from the wiki.
