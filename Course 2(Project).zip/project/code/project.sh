./project.py > log.txt
