# Course 4 Week 2 (Sample-Based Planning) Project

## Contents
- `code` is where all code is located. `project.py` implements a rapidly
exploring random tree (RRT) path planning algorithm.
- `results` is where the input `obstacles.csv` and output `path.csv`,
`nodes.csv`, and `edges.csv` files are stored.
- `ss.png` is a screenshot of the simulation environment showing the path.
